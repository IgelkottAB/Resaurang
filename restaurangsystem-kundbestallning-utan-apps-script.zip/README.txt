RESTAURANGSYSTEM – KUNDORDER UTAN APPS SCRIPT/FIREBASE/NODE

Den här versionen använder ntfy.sh som en färdig webbtjänst för att skicka kundbeställningar i realtid.
Det kräver inget Firebase-projekt, Google Apps Script eller Node.js.

FILER
- index.html / script.js / style.css = personalsystemet
- kundsida.html = kundsidan som du sätter bakom QR-koder
- ntfy-config.js = gemensam kanal
- detta README

QR-KODER
Exempel:
https://DIN-WEBSIDA/kundsida.html?bord=1
https://DIN-WEBSIDA/kundsida.html?bord=2
https://DIN-WEBSIDA/kundsida.html?bord=3

Kunden behöver bara skanna rätt QR-kod. Bordsnumret läses från ?bord=.

HUR BESTÄLLNINGEN GÅR
1. Kunden öppnar kundsidan.
2. Kunden lägger varor i varukorgen.
3. Kunden trycker "Skicka beställning".
4. Kundsidan skickar ordern till den gemensamma ntfy-kanalen.
5. Personalsystemet lyssnar på samma kanal och lägger ordern på rätt bord.
6. Kökets status kan skickas tillbaka: Ny/Tillagas/Klar för servering.

VIKTIGT OM NTFY
Detta är en demo/prototyplösning. ntfy kräver ingen inloggning och en topic fungerar i praktiken som en delad kanal/nyckel. Håll topic-namnet hemligt.
Beställningar kan även vara synliga för den som känner till topic-namnet. Lägg därför inte riktiga personuppgifter, kortuppgifter eller annan känslig information där.

TILLFÖRLITLIGHET
Detta är livekommunikation, inte en riktig restaurangdatabas. ntfy har servercache, men det finns ingen garanti här som i en egen databas. Personalsidan bör därför vara öppen när restaurangen tar emot beställningar.

INGEN BETALNING
Kundens sida hanterar inte riktig betalning. Betalning görs fortfarande i personalsystemets demo-kassa.

KÄLLA
ntfy har officiellt stöd för att publicera med fetch() och prenumerera från JavaScript via EventSource/SSE:
https://docs.ntfy.sh/publish/
https://docs.ntfy.sh/subscribe/api/
